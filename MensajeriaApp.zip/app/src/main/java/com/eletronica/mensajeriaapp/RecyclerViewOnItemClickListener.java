package com.eletronica.mensajeriaapp;

import android.view.View;

public interface  RecyclerViewOnItemClickListener {

    void onClick(View v, int position);
}
