package com.eletronica.mensajeriaapp.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Utils {
    public static List<List<HashMap<String,String>>>routes=new ArrayList<>();
}
