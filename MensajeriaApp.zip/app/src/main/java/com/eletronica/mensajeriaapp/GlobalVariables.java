package com.eletronica.mensajeriaapp;

public class GlobalVariables {
    public static final String URLServicio = "https://erp.servfix.com.mx/ws/mensajeriaapp/";
    //public static final String URLServicio = "https://sistema.lavadorasleon.com/ws/mensajeriaapp/";
    public static int id_usuario;
    public static String usuario;
    public static String nombre;
    public static String descripcion_rol;
    public static int rol;
    public static byte[] foto;
}

